#include "MainMenu.h"


#define MainMenu_WIDTH 20
#define MainMenu_HEIGHT 8
unsigned int MainMenu_data[] =
{

	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

void MainMenu::Initialize() {
	GLuint mapTextureId = Util::LoadTexture("tileset.png");
	state.map = new Map(MainMenu_WIDTH, MainMenu_HEIGHT, MainMenu_data, mapTextureId, 1.0f, 4, 1);
	state.player.textureID = Util::LoadTexture("Welcome.png");
	state.player.cols = 1;
	state.player.rows = 1;
	state.player.animIndices = new int[1]{ 0 };
	state.player.animFrames = 1;

	state.enemy2.textureID = Util::LoadTexture("Noloz.png");
	state.enemy2.cols = 1;
	state.enemy2.rows = 1;
	state.enemy2.animIndices = new int[1]{ 0 };
	state.enemy2.animFrames = 1;



	state.player.position = glm::vec3(5, -3, 0);
	state.enemy2.position = glm::vec3(5, -3.5, 0);
	state.enemycount = 1;
	state.nextLevel = -1;


}

void MainMenu::Update(float deltaTime) {
	state.player.Update(deltaTime, NULL, 0, state.map);
}

void MainMenu::Render(ShaderProgram* program) {
	state.player.Render(program);
	state.enemy2.Render(program);
}