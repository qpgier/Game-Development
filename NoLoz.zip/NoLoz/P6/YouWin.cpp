#include "YouWin.h"


#define YouWin_WIDTH 20
#define YouWin_HEIGHT 8
unsigned int YouWin_data[] =
{

	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

void YouWin::Initialize() {
	GLuint mapTextureId = Util::LoadTexture("tileset.png");
	state.map = new Map(YouWin_WIDTH, YouWin_HEIGHT, YouWin_data, mapTextureId, 1.0f, 4, 1);
	state.player.textureID = Util::LoadTexture("YouWin.png");
	state.player.position = glm::vec3(5, -3, 0);
	state.player.width = 1.0f;
	state.player.rows = 1;
	state.player.cols = 1;
	state.player.animIndices = new int[1]{ 0 };
	state.player.animFrames = 1;
	state.enemycount = 1;
	state.nextLevel = -1;


}

void YouWin::Update(float deltaTime) {
	state.player.Update(deltaTime, NULL, 0, state.map);
}

void YouWin::Render(ShaderProgram* program) {
	state.player.Render(program);
}
