#include "Level1.h"

#define LEVEL1_WIDTH 10
#define LEVEL1_HEIGHT 8

unsigned int level1_data[] =
{ 
	62,  62, 62, 0,  62, 62, 62, 62, 62, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0, 62,
	62,  62, 62, 62, 62, 62, 62, 62, 62, 62
};

void Level1::Initialize() {
	GLuint mapTextureId = Util::LoadTexture("tiles.png");
	state.map = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level1_data, mapTextureId, 1.0f, 16, 16);
	state.enemycount = 1;
	state.coincount = 1;
	state.player.entityType = PLAYER;
	state.player.isStatic = false;
	state.player.width = 0.8f;

	if (state.player.newGame == true) {
		state.player.position = glm::vec3(5, -3, 0);
		state.coin1.position = glm::vec3(5, -2, 0);
		state.transport.position = glm::vec3(16, 16, 0);
		state.transport.isActive = false;
		state.coin1.isActive = true;
		state.player.newGame = false;
	}
	//state.player.acceleration = glm::vec3(0, -9.81, 0);
	state.player.textureID = Util::LoadTexture("link.png");
	state.player.rows = 8;
	state.player.cols = 12;
	state.player.animIndices = new int[1]{24};
	state.player.animFrames = 1;
	state.nextLevel = -1;


	state.transport.width = 1.0f;
	state.transport.textureID = Util::LoadTexture("swirl.png");
	state.transport.cols = 7;
	state.transport.rows = 6;
	state.transport.animIndices = new int[41]{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 ,40, };
	state.transport.animFrames = 41;

	state.coin1.width = 1.0f;
	state.coin1.textureID = Util::LoadTexture("coin.png");
	state.coin1.cols = 8;
	state.coin1.rows = 6;
	state.coin1.animIndices = new int[8]{ 0,1,2,3,4,5,6,7 };
	state.coin1.animFrames = 8;


}

void Level1::Update(float deltaTime) {
	state.player.Update(deltaTime, NULL, 0, state.map);


}

void Level1::Render(ShaderProgram* program) {
	state.map->Render(program);
	state.player.Render(program);
	state.transport.Render(program);
	state.coin1.Render(program);

}