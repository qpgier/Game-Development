#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <vector>
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"  
#include "ShaderProgram.h"

#include "Entity.h"
#include "Map.h"
#include "Util.h"
#include "Scene.h"
#include "MainMenu.h"
#include "Level-1.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "YouWin.h"
#include "YouLose.h"
#include "SDL_mixer.h"



Scene* currentScene;
Scene* sceneList[7];

GLuint fontTextureID;

SDL_Window* displayWindow;
bool gameIsRunning = true;

Mix_Music* musicplay;
Mix_Music* musicwin;

Mix_Chunk* coin;
Mix_Chunk* die;
Mix_Chunk* teleport;
Mix_Chunk* allcoins;


ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

int scenetracker = 1;
int lives = 3;

void SwitchToScene(Scene* scene) {
	currentScene = scene;
	currentScene->Initialize();
}
void Initialize() {
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
	displayWindow = SDL_CreateWindow("P6", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1000, 750, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 8192);



#ifdef _WINDOWS
	glewInit();
#endif
	glViewport(0, 0, 1000, 750);
	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");

	musicwin = Mix_LoadMUS("win.mp3");
	musicplay = Mix_LoadMUS("play.mp3");

	
	die = Mix_LoadWAV("die.wav");
	coin = Mix_LoadWAV("coin.wav");
	allcoins = Mix_LoadWAV("allcoins.wav");
	teleport = Mix_LoadWAV("warp.wav");

	Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
	Mix_PlayMusic(musicplay, -1);

	viewMatrix = glm::mat4(1.0f);
	modelMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

	glUseProgram(program.programID);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);


	sceneList[0] = new Level0();
	sceneList[1] = new MainMenu();
	sceneList[2] = new Level1();
	sceneList[3] = new Level2();
	sceneList[4] = new Level3();
	sceneList[5] = new YouLose();
	sceneList[6] = new YouWin();
	SwitchToScene(sceneList[scenetracker]);
}

void ProcessInput() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
		case SDL_WINDOWEVENT_CLOSE:
			gameIsRunning = false;
			break;

		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
			case SDLK_RETURN:
				if (scenetracker == 1) {
					scenetracker += 1;
					SwitchToScene(sceneList[scenetracker]);
				}
				break;
			case SDLK_d:
				currentScene->state.player.animIndices = new int[24]{ 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 60, 61, 62, 63, 64, 65 ,66, 67, 68, 69, 70, 71 };
				currentScene->state.player.animFrames = 24;
				currentScene->state.player.left = false;
				currentScene->state.player.right = true;
				currentScene->state.player.up = false;
				currentScene->state.player.down = false;
				break;
			case SDLK_w:
				currentScene->state.player.animIndices = new int[24]{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59 };
				currentScene->state.player.animFrames = 24;
				currentScene->state.player.left = false;
				currentScene->state.player.right = false;
				currentScene->state.player.up = true;
				currentScene->state.player.down = false;
				break;
			case SDLK_s:
				currentScene->state.player.animIndices = new int[24]{24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83};
				currentScene->state.player.animFrames = 24;
				currentScene->state.player.left = false;
				currentScene->state.player.right = false;
				currentScene->state.player.up = false;
				currentScene->state.player.down = true;
				break;
			case SDLK_a:
				currentScene->state.player.animIndices = new int[24]{ 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95};
				currentScene->state.player.animFrames = 24;
				currentScene->state.player.right = false;
				currentScene->state.player.left = true;
				currentScene->state.player.down = false;
				currentScene->state.player.up = false;
				break;
			}
			break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym) {
			case SDLK_w:
				currentScene->state.player.velocity.y = 0.0f;
				currentScene->state.player.animIndices = new int[1]{ 2 };
				currentScene->state.player.animFrames = 1;
				break;
			case SDLK_s:
				currentScene->state.player.velocity.y = 0.0f;
				currentScene->state.player.animIndices = new int[1]{ 25 };
				currentScene->state.player.animFrames = 1;
				break;
			case SDLK_a:
				currentScene->state.player.velocity.x = 0.0f;
				currentScene->state.player.animIndices = new int[1]{ 37 };
				currentScene->state.player.animFrames = 1;
				break;
			case SDLK_d:
				currentScene->state.player.velocity.x = 0.0f;
				currentScene->state.player.animIndices = new int[1]{ 13 };
				currentScene->state.player.animFrames = 1;
				break;
			}
		}
	}

	currentScene->state.player.velocity.x = 0;

	// Check for pressed/held keys below
	const Uint8* keys = SDL_GetKeyboardState(NULL);

	if (keys[SDL_SCANCODE_A])
	{
		currentScene->state.player.velocity.x = -3.0f;
	}
	else if (keys[SDL_SCANCODE_D])
	{
		currentScene->state.player.velocity.x = 3.0f;
	}
	else if (keys[SDL_SCANCODE_W])
	{
		currentScene->state.player.velocity.y = 3.0f;
	}
	else if (keys[SDL_SCANCODE_S])
	{
		currentScene->state.player.velocity.y = -3.0f;
	}

}

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;


	deltaTime += accumulator;
	if (deltaTime < FIXED_TIMESTEP) {
		accumulator = deltaTime;
		return;
	}

	while (deltaTime >= FIXED_TIMESTEP) {

		currentScene->state.player.Update(FIXED_TIMESTEP, currentScene->state.enemies, ENEMY_COUNT, currentScene->state.map);
		currentScene->state.enemy1.Update(FIXED_TIMESTEP, currentScene->state.enemies, ENEMY_COUNT, currentScene->state.map);
		currentScene->state.enemy2.Update(FIXED_TIMESTEP, currentScene->state.enemies, ENEMY_COUNT, currentScene->state.map);
		currentScene->state.transport.Update(FIXED_TIMESTEP, currentScene->state.enemies, ENEMY_COUNT, currentScene->state.map);

		deltaTime -= FIXED_TIMESTEP;
	}

	accumulator = deltaTime;
	viewMatrix = glm::mat4(1.0f);
	if (currentScene->state.player.position.x > 5) {
		viewMatrix = glm::translate(viewMatrix, glm::vec3(-currentScene->state.player.position.x, 3.75, 0));
	}

	else {
		viewMatrix = glm::translate(viewMatrix, glm::vec3(-5, 3.75, 0));
	}


	if (currentScene->state.player.CheckCollision(currentScene->state.enemy1)) {
			lives -= 1;
			Mix_PlayChannel(-1, die, 0);
			SwitchToScene(sceneList[scenetracker]);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.enemy2)) {
			lives -= 1;
			Mix_PlayChannel(-1, die, 0);
			SwitchToScene(sceneList[scenetracker]);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.transport)) {
		if (scenetracker == 4) {
			SwitchToScene(sceneList[6]);
			Mix_PlayMusic(musicwin, -1);
		}
		else {
			currentScene->state.nextLevel += 1;
			Mix_PlayChannel(-1, teleport, 0);
		}
	}

	if (currentScene->state.player.CheckCollision(currentScene->state.coin1)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin1.position = glm::vec3(20, 20, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin2)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin2.position = glm::vec3(22, 22, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin3)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin3.position = glm::vec3(22, 24, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin4)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin4.position = glm::vec3(22, 28, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin5)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin5.position = glm::vec3(22, 30, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin6)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin6.position = glm::vec3(22, 32, 0);
	}
	if (currentScene->state.player.CheckCollision(currentScene->state.coin7)) {
		currentScene->state.coincount -= 1;
		if (currentScene->state.coincount == 0) {
			Mix_PlayChannel(-1, allcoins, 0);
		}
		else {
			Mix_PlayChannel(-1, coin, 0);
		}
		currentScene->state.coin7.position = glm::vec3(22, 34, 0);
	}

	if (currentScene->state.coincount == 0) {
		if (scenetracker == 2){
			currentScene->state.transport.position = glm::vec3(5, -5, 0);
			currentScene->state.transport.isActive = true;
		}
		else if (scenetracker == 3) {
			currentScene->state.transport.position = glm::vec3(10, -5, 0);
			currentScene->state.transport.isActive = true;
		}
		else if (scenetracker == 4) {
			currentScene->state.transport.position = glm::vec3(39, -6, 0);
			currentScene->state.transport.isActive = true;
		}
	}
	if (lives == 0) {
		SwitchToScene(sceneList[4]);
		
	}

	if (scenetracker == 2) {
		if (currentScene->state.player.position.y > 0) {
			scenetracker = 3;
			SwitchToScene(sceneList[3]);
			currentScene->state.player.position = glm::vec3(3, -7, 0);
		}
	}
	if (scenetracker == 3) {
		if (currentScene->state.player.position.y < -7) {
			scenetracker = 2;
			SwitchToScene(sceneList[2]);
			currentScene->state.player.position = glm::vec3(3, 0, 0);
		}
	}

	if (scenetracker == 4) {
		if (currentScene->state.enemy1.position.y <= -3) {
			currentScene->state.enemy1.velocity = glm::vec3(0.9, 2.5, 0);
		}
		if (currentScene->state.enemy1.position.y >= -1) {
			currentScene->state.enemy1.velocity = glm::vec3(0.9, -2.5, 0);
		}
		if (currentScene->state.enemy2.position.y <= -6) {
			currentScene->state.enemy2.velocity = glm::vec3(0.9, 2.5, 0);
		}
		if (currentScene->state.enemy2.position.y >= -4) {
			currentScene->state.enemy2.velocity = glm::vec3(0.9, -2.5, 0);
		}
	}

}


void Render() {
	glClear(GL_COLOR_BUFFER_BIT);
	program.SetViewMatrix(viewMatrix);
	currentScene->Render(&program);

	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	Mix_HaltMusic();
	Mix_FreeMusic(musicwin);
	Mix_FreeMusic(musicplay);
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		Update();
		Render();
		if (currentScene->state.nextLevel >= 0) {
			scenetracker += 1;
			SwitchToScene(sceneList[scenetracker]);
		}
	}

	Shutdown();
	return 0;
}
