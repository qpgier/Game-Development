#pragma once
#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "SDL_mixer.h"

#include "Util.h"
#include "Entity.h"
#include "Map.h"

#define ENEMY_COUNT 5

struct GameState {
	Entity player;
	Entity enemies[ENEMY_COUNT];
	Entity enemy1;
	Entity enemy2;
	Entity enemy3;
	Entity coin1;
	Entity coin2;
	Entity coin3;
	Entity coin4;
	Entity coin5;
	Entity coin6;
	Entity coin7;

	Entity transport;
	Map* map;
	int nextLevel;
	int enemycount;
	int coincount;
	GLuint fontTextureID;
	Mix_Music* music;

};

class Scene {
public:
	GameState state;
	virtual void Initialize() = 0;
	virtual void Update(float deltaTime) = 0;
	virtual void Render(ShaderProgram* program) = 0;
};