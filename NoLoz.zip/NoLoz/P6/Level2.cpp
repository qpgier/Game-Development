#include "Level2.h"

#define LEVEL2_WIDTH 10
#define LEVEL2_HEIGHT 8

unsigned int level2_data[] =
{

	62,  62, 62, 62, 62, 62, 62, 62, 62, 62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  0,  0,  0,  0,  0,  0,  0,  0,  62,
	62,  62, 62, 0,  62, 62, 62, 62, 62, 62

};

void Level2::Initialize() {
	GLuint mapTextureId = Util::LoadTexture("tiles.png");
	state.map = new Map(LEVEL2_WIDTH, LEVEL2_HEIGHT, level2_data, mapTextureId, 1.0f, 16, 16);

	state.enemycount = 2;
	state.coincount = 4;
	state.player.entityType = PLAYER;
	state.player.isStatic = false;
	state.player.width = 0.75f;
	state.player.textureID = Util::LoadTexture("link.png");
	state.nextLevel = -1;
	state.player.rows = 8;
	state.player.cols = 12;
	state.player.animIndices = new int[1]{ 24 };
	state.player.animFrames = 1;
	state.nextLevel = -1;


	state.coin1.width = 1.0f;
	state.coin1.position = glm::vec3(5, -2, 0);
	state.coin1.textureID = Util::LoadTexture("coin.png");
	state.coin1.isActive = true;
	state.coin1.cols = 8;
	state.coin1.rows = 6;
	state.coin1.animIndices = new int[8]{ 0,1,2,3,4,5,6,7 };
	state.coin1.animFrames = 8;

	state.coin2.width = 1.0f;
	state.coin2.position = glm::vec3(15, -2, 0);
	state.coin2.textureID = Util::LoadTexture("coin.png");
	state.coin2.isActive = true;
	state.coin2.cols = 8;
	state.coin2.rows = 6;
	state.coin2.animIndices = new int[8]{ 0,1,2,3,4,5,6,7 };
	state.coin2.animFrames = 8;

	state.coin3.width = 1.0f;
	state.coin3.position = glm::vec3(5, -6, 0);
	state.coin3.textureID = Util::LoadTexture("coin.png");
	state.coin3.isActive = true;
	state.coin3.cols = 8;
	state.coin3.rows = 6;
	state.coin3.animIndices = new int[8]{ 0,1,2,3,4,5,6,7 };
	state.coin3.animFrames = 8;

	state.coin4.width = 1.0f;
	state.coin4.position = glm::vec3(15, -6, 0);
	state.coin4.textureID = Util::LoadTexture("coin.png");
	state.coin4.isActive = true;
	state.coin4.cols = 8;
	state.coin4.rows = 6;
	state.coin4.animIndices = new int[8]{ 0,1,2,3,4,5,6,7 };
	state.coin4.animFrames = 8;

	state.transport.width = 1.0f;
	state.transport.position = glm::vec3(20, 10, 0);
	state.transport.textureID = Util::LoadTexture("swirl.png");
	state.transport.isActive = false;
	state.transport.cols = 7;
	state.transport.rows = 6;
	state.transport.animIndices = new int[41]{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 ,40, };
	state.transport.animFrames = 41;

}

void Level2::Update(float deltaTime) {
	state.player.Update(deltaTime, NULL, 0, state.map);
}

void Level2::Render(ShaderProgram* program) {
	state.map->Render(program);
	state.player.Render(program);
	state.transport.Render(program);
	state.coin1.Render(program);
	state.coin2.Render(program);
	state.coin3.Render(program);
	state.coin4.Render(program);
}