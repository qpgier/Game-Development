#include "Level0.h"

#define LEVEL1_WIDTH 10
#define LEVEL1_HEIGHT 8

unsigned int level0_data[] =
{
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,   0,  0,  0,  0,  0,  0,  0,  0,  0,

};

void Level0::Initialize() {
	GLuint mapTextureId = Util::LoadTexture("tiles.png");
	state.map = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level0_data, mapTextureId, 1.0f, 16, 16);
	state.enemycount = 1;
	state.coincount = 2;
	state.player.entityType = PLAYER;
	state.player.isStatic = false;
	state.player.width = 0.8f;

	//state.player.acceleration = glm::vec3(0, -9.81, 0);
	state.player.textureID = Util::LoadTexture("link.png");
	state.player.rows = 8;
	state.player.cols = 12;
	state.player.animIndices = new int[1]{ 24 };
	state.player.animFrames = 1;
	state.nextLevel = -1;
}

void Level0::Update(float deltaTime) {
	state.player.Update(deltaTime, NULL, 0, state.map);


}

void Level0::Render(ShaderProgram* program) {
	state.map->Render(program);
	state.player.Render(program);
	state.transport.Render(program);
	state.coin1.Render(program);
	state.coin2.Render(program);

}